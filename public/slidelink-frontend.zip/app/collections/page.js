"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, BookOpen, Plus } from "lucide-react"
import Link from "next/link"
import CollectionCard from "@/components/ui/CollectionCard"
import { FACULTIES } from "@/lib/constants"

export default function CollectionsPage() {
  const [collections, setCollections] = useState([])
  const [filteredCollections, setFilteredCollections] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("")
  const [sortBy, setSortBy] = useState("newest")

  useEffect(() => {
    // Load collections from localStorage
    const stored = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    setCollections(stored)
    setFilteredCollections(stored)
  }, [])

  useEffect(() => {
    // Filter and sort collections
    const filtered = collections.filter((collection) => {
      const matchesSearch =
        collection.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        collection.sectionBatch.toLowerCase().includes(searchTerm.toLowerCase()) ||
        collection.id.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesDepartment = !selectedDepartment || collection.department.includes(selectedDepartment)

      return matchesSearch && matchesDepartment
    })

    // Sort collections
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.createdAt) - new Date(a.createdAt)
        case "oldest":
          return new Date(a.createdAt) - new Date(b.createdAt)
        case "course":
          return a.courseCode.localeCompare(b.courseCode)
        case "section":
          return a.sectionBatch.localeCompare(b.sectionBatch)
        default:
          return 0
      }
    })

    setFilteredCollections(filtered)
  }, [collections, searchTerm, selectedDepartment, sortBy])

  // Get all departments for filter
  const allDepartments = FACULTIES.flatMap((faculty) => faculty.departments.map((dept) => dept.name))

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">All Collections</h1>
          <p className="text-gray-600">Browse and manage slide collections</p>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="card mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search by course code or section..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-10"
              />
            </div>

            {/* Department Filter */}
            <div>
              <select
                value={selectedDepartment}
                onChange={(e) => setSelectedDepartment(e.target.value)}
                className="input-field"
              >
                <option value="">All Departments</option>
                {allDepartments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="input-field">
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="course">Course Code</option>
                <option value="section">Section</option>
              </select>
            </div>

            {/* Create Button */}
            <Link href="/create" className="btn-primary inline-flex items-center justify-center gap-2">
              <Plus size={20} />
              Create New
            </Link>
          </div>
        </motion.div>

        {/* Collections Grid */}
        {filteredCollections.length > 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredCollections.map((collection, index) => (
              <motion.div
                key={collection.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <CollectionCard collection={collection} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-500 mb-2">
              {collections.length === 0 ? "No Collections Yet" : "No Collections Found"}
            </h3>
            <p className="text-gray-400 mb-6">
              {collections.length === 0
                ? "Create your first collection to get started"
                : "Try adjusting your search or filter criteria"}
            </p>
            {collections.length === 0 && (
              <Link href="/create" className="btn-primary inline-flex items-center gap-2">
                <Plus size={20} />
                Create First Collection
              </Link>
            )}
          </motion.div>
        )}

        {/* Stats */}
        {collections.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-12 text-center text-gray-500"
          >
            <p>
              Showing {filteredCollections.length} of {collections.length} collections
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}
