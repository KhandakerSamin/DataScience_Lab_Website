"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { BookOpen, Plus, Clock, Users, FileText } from "lucide-react"
import CollectionCard from "@/components/ui/CollectionCard"

export default function HomePage() {
  const [recentCollections, setRecentCollections] = useState([])
  const [stats, setStats] = useState({ total: 0, active: 0, submissions: 0 })

  useEffect(() => {
    // Load recent collections from localStorage
    const collections = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    const recent = collections.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 6)

    setRecentCollections(recent)

    // Calculate stats
    const now = new Date()
    const active = collections.filter((c) => new Date(c.expiresAt) > now).length
    const totalSubmissions = collections.reduce((sum, c) => sum + (c.submissions?.length || 0), 0)

    setStats({
      total: collections.length,
      active,
      submissions: totalSubmissions,
    })
  }, [])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-6">
              SlideLink
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Streamline the collection and management of presentation slides from students in academic institutions.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link href="/create" className="btn-primary inline-flex items-center gap-2">
                <Plus size={20} />
                Create Collection
              </Link>
              <Link href="/collections" className="btn-secondary inline-flex items-center gap-2">
                <BookOpen size={20} />
                View All Collections
              </Link>
            </div>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          >
            <motion.div variants={itemVariants} className="card text-center">
              <FileText className="w-8 h-8 text-blue-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-gray-800">{stats.total}</h3>
              <p className="text-gray-600">Total Collections</p>
            </motion.div>
            <motion.div variants={itemVariants} className="card text-center">
              <Clock className="w-8 h-8 text-green-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-gray-800">{stats.active}</h3>
              <p className="text-gray-600">Active Collections</p>
            </motion.div>
            <motion.div variants={itemVariants} className="card text-center">
              <Users className="w-8 h-8 text-purple-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-gray-800">{stats.submissions}</h3>
              <p className="text-gray-600">Total Submissions</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Recent Collections */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Recent Collections</h2>
            <p className="text-gray-600">Latest slide collections created by instructors</p>
          </motion.div>

          {recentCollections.length > 0 ? (
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {recentCollections.map((collection, index) => (
                <motion.div key={collection.id} variants={itemVariants}>
                  <CollectionCard collection={collection} />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-500 mb-2">No Collections Yet</h3>
              <p className="text-gray-400 mb-6">Create your first collection to get started</p>
              <Link href="/create" className="btn-primary inline-flex items-center gap-2">
                <Plus size={20} />
                Create First Collection
              </Link>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  )
}
