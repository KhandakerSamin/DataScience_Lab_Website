"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { Plus, Calendar, Users, BookOpen, Lock, FileText } from "lucide-react"
import { FACULTIES } from "@/lib/constants"

export default function CreateCollection() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    sectionBatch: "",
    courseCode: "",
    semester: "",
    faculty: "",
    department: "",
    password: "",
    description: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState({})

  // Get departments based on selected faculty
  const getDepartments = () => {
    const faculty = FACULTIES.find((f) => f.name === formData.faculty)
    return faculty ? faculty.departments : []
  }

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
      // Reset department when faculty changes
      ...(name === "faculty" && { department: "" }),
    }))

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  // Validate form data
  const validateForm = () => {
    const newErrors = {}

    if (!formData.sectionBatch.match(/^\d{2}-[A-Z]$/)) {
      newErrors.sectionBatch = 'Format should be like "42-E"'
    }

    if (!formData.courseCode.match(/^[A-Z]{2,4}\d{3}$/)) {
      newErrors.courseCode = 'Format should be like "SE112" or "CSE101"'
    }

    if (!formData.semester) newErrors.semester = "Semester is required"
    if (!formData.faculty) newErrors.faculty = "Faculty is required"
    if (!formData.department) newErrors.department = "Department is required"
    if (!formData.password || formData.password.length < 4) {
      newErrors.password = "Password must be at least 4 characters"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsLoading(true)

    try {
      // Generate collection ID
      const faculty = FACULTIES.find((f) => f.name === formData.faculty)
      const department = faculty.departments.find((d) => d.name === formData.department)
      const year = new Date().getFullYear()
      const collectionId = `${formData.sectionBatch}-${formData.courseCode}-${year}-${department.code}`

      // Create collection object
      const collection = {
        id: collectionId,
        ...formData,
        departmentCode: department.code,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
        submissions: [],
      }

      // Save to localStorage
      const collections = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
      collections.push(collection)
      localStorage.setItem("slidelink_collections", JSON.stringify(collections))

      // Redirect to collection success page
      router.push(`/collection-created/${department.code}/${collectionId}`)
    } catch (error) {
      console.error("Error creating collection:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Create New Collection</h1>
          <p className="text-gray-600">Set up a new slide collection for your course</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="card"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Section & Batch */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Users className="w-4 h-4 inline mr-2" />
                Section & Batch *
              </label>
              <input
                type="text"
                name="sectionBatch"
                value={formData.sectionBatch}
                onChange={handleChange}
                placeholder="e.g., 42-E, 65-A"
                className={`input-field ${errors.sectionBatch ? "border-red-500" : ""}`}
              />
              {errors.sectionBatch && <p className="text-red-500 text-sm mt-1">{errors.sectionBatch}</p>}
            </div>

            {/* Course Code */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <BookOpen className="w-4 h-4 inline mr-2" />
                Course Code *
              </label>
              <input
                type="text"
                name="courseCode"
                value={formData.courseCode}
                onChange={handleChange}
                placeholder="e.g., SE112, CSE101"
                className={`input-field ${errors.courseCode ? "border-red-500" : ""}`}
              />
              {errors.courseCode && <p className="text-red-500 text-sm mt-1">{errors.courseCode}</p>}
            </div>

            {/* Semester */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-2" />
                Semester *
              </label>
              <select
                name="semester"
                value={formData.semester}
                onChange={handleChange}
                className={`input-field ${errors.semester ? "border-red-500" : ""}`}
              >
                <option value="">Select Semester</option>
                <option value="Spring 2025">Spring 2025</option>
                <option value="Summer 2025">Summer 2025</option>
                <option value="Fall 2025">Fall 2025</option>
              </select>
              {errors.semester && <p className="text-red-500 text-sm mt-1">{errors.semester}</p>}
            </div>

            {/* Faculty */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Faculty *</label>
              <select
                name="faculty"
                value={formData.faculty}
                onChange={handleChange}
                className={`input-field ${errors.faculty ? "border-red-500" : ""}`}
              >
                <option value="">Select Faculty</option>
                {FACULTIES.map((faculty) => (
                  <option key={faculty.name} value={faculty.name}>
                    {faculty.name}
                  </option>
                ))}
              </select>
              {errors.faculty && <p className="text-red-500 text-sm mt-1">{errors.faculty}</p>}
            </div>

            {/* Department */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Department *</label>
              <select
                name="department"
                value={formData.department}
                onChange={handleChange}
                disabled={!formData.faculty}
                className={`input-field ${errors.department ? "border-red-500" : ""} ${!formData.faculty ? "opacity-50" : ""}`}
              >
                <option value="">Select Department</option>
                {getDepartments().map((dept) => (
                  <option key={dept.name} value={dept.name}>
                    {dept.name}
                  </option>
                ))}
              </select>
              {errors.department && <p className="text-red-500 text-sm mt-1">{errors.department}</p>}
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Collection Password *
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter collection password"
                className={`input-field ${errors.password ? "border-red-500" : ""}`}
              />
              {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="w-4 h-4 inline mr-2" />
                Description (Optional)
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Add any additional information about this collection..."
                rows={3}
                className="input-field resize-none"
              />
            </div>

            {/* Submit Button */}
            <motion.button
              type="submit"
              disabled={isLoading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Creating Collection...
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <Plus size={20} />
                  Create Collection
                </div>
              )}
            </motion.button>
          </form>
        </motion.div>
      </div>
    </div>
  )
}
