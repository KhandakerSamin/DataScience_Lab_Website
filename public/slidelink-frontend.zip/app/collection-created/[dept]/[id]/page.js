"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { CheckCircle, Copy, ExternalLink, Plus, Clock, Users } from "lucide-react"
import QRCodeGenerator from "@/components/ui/QRCodeGenerator"

export default function CollectionCreated() {
  const params = useParams()
  const router = useRouter()
  const [collection, setCollection] = useState(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    // Load collection from localStorage
    const collections = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    const found = collections.find((c) => c.id === params.id)

    if (!found) {
      router.push("/")
      return
    }

    setCollection(found)
  }, [params.id, router])

  const collectionUrl = `${window.location.origin}/collection/${params.dept}/${params.id}`

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(collectionUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy:", err)
    }
  }

  if (!collection) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  const timeRemaining = new Date(collection.expiresAt) - new Date()
  const hoursRemaining = Math.floor(timeRemaining / (1000 * 60 * 60))

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Success Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Collection Created Successfully!</h1>
          <p className="text-gray-600">Your slide collection is now ready to receive submissions</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Collection Details */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="card"
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Collection Details</h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Collection ID</span>
                <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">{collection.id}</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Course</span>
                <span className="font-medium">
                  {collection.sectionBatch} - {collection.courseCode}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Semester</span>
                <span className="font-medium">{collection.semester}</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Department</span>
                <span className="font-medium">{collection.department}</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600 flex items-center gap-2">
                  <Clock size={16} />
                  Expires In
                </span>
                <span className="font-medium text-orange-600">{hoursRemaining} hours</span>
              </div>

              <div className="flex items-center justify-between py-2">
                <span className="text-gray-600 flex items-center gap-2">
                  <Users size={16} />
                  Submissions
                </span>
                <span className="font-medium">{collection.submissions.length}</span>
              </div>
            </div>

            {collection.description && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-medium text-gray-800 mb-2">Description</h3>
                <p className="text-gray-600 text-sm">{collection.description}</p>
              </div>
            )}
          </motion.div>

          {/* QR Code & URL */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="card"
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Share Collection</h2>

            {/* QR Code */}
            <div className="text-center mb-6">
              <QRCodeGenerator url={collectionUrl} />
            </div>

            {/* Collection URL */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Collection URL</label>
              <div className="flex gap-2">
                <input type="text" value={collectionUrl} readOnly className="input-field flex-1 font-mono text-sm" />
                <button
                  onClick={copyToClipboard}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                  title="Copy URL"
                >
                  <Copy size={16} className={copied ? "text-green-500" : "text-gray-600"} />
                </button>
              </div>
              {copied && <p className="text-green-500 text-sm mt-1">URL copied to clipboard!</p>}
            </div>

            {/* Password Info */}
            <div className="p-4 bg-yellow-50 rounded-lg mb-6">
              <h3 className="font-medium text-gray-800 mb-2">Important</h3>
              <p className="text-sm text-gray-600">
                Students will need the collection password to access and submit slides. Make sure to share the password
                securely with your students.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mt-8"
        >
          <Link
            href={`/collection/${params.dept}/${params.id}`}
            className="btn-primary inline-flex items-center justify-center gap-2"
          >
            <ExternalLink size={20} />
            Enter the Collection
          </Link>

          <Link href="/create" className="btn-secondary inline-flex items-center justify-center gap-2">
            <Plus size={20} />
            Create New Collection
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
