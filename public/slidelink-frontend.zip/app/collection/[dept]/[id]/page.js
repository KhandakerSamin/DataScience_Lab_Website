"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useParams } from "next/navigation"
import { Lock, Clock, Users, ExternalLink, Plus, Search, BookOpen } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { isValidSlideLink } from "@/lib/constants"

export default function CollectionPage() {
  const params = useParams()
  const [collection, setCollection] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [submissions, setSubmissions] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showSubmissionForm, setShowSubmissionForm] = useState(false)
  const [submissionForm, setSubmissionForm] = useState({
    teamName: "",
    slideLink: "",
    leaderEmail: "",
    notes: "",
  })
  const [submissionErrors, setSubmissionErrors] = useState({})

  useEffect(() => {
    // Load collection from localStorage
    const collections = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    const found = collections.find((c) => c.id === params.id)

    if (found) {
      setCollection(found)
      setSubmissions(found.submissions || [])
    }
  }, [params.id])

  const handlePasswordSubmit = (e) => {
    e.preventDefault()
    if (collection && password === collection.password) {
      setIsAuthenticated(true)
      setPasswordError("")
    } else {
      setPasswordError("Incorrect password")
    }
  }

  const handleSubmissionChange = (e) => {
    const { name, value } = e.target
    setSubmissionForm((prev) => ({ ...prev, [name]: value }))

    // Clear error when user starts typing
    if (submissionErrors[name]) {
      setSubmissionErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const validateSubmission = () => {
    const errors = {}

    if (!submissionForm.teamName.trim()) {
      errors.teamName = "Team name is required"
    } else if (submissions.some((s) => s.teamName.toLowerCase() === submissionForm.teamName.toLowerCase())) {
      errors.teamName = "Team name already exists"
    }

    if (!submissionForm.slideLink.trim()) {
      errors.slideLink = "Slide link is required"
    } else if (!isValidSlideLink(submissionForm.slideLink)) {
      errors.slideLink = "Please provide a valid Google Drive or OneDrive link"
    }

    if (submissionForm.leaderEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(submissionForm.leaderEmail)) {
      errors.leaderEmail = "Please provide a valid email address"
    }

    setSubmissionErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSubmissionSubmit = (e) => {
    e.preventDefault()

    if (!validateSubmission()) return

    const newSubmission = {
      id: Date.now(),
      ...submissionForm,
      submittedAt: new Date().toISOString(),
    }

    // Update submissions
    const updatedSubmissions = [...submissions, newSubmission]
    setSubmissions(updatedSubmissions)

    // Update collection in localStorage
    const collections = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    const updatedCollections = collections.map((c) =>
      c.id === collection.id ? { ...c, submissions: updatedSubmissions } : c,
    )
    localStorage.setItem("slidelink_collections", JSON.stringify(updatedCollections))

    // Reset form
    setSubmissionForm({ teamName: "", slideLink: "", leaderEmail: "", notes: "" })
    setShowSubmissionForm(false)

    // Show success message (you could add a toast notification here)
    alert("Submission successful!")
  }

  const filteredSubmissions = submissions.filter(
    (submission) =>
      submission.teamName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (submission.leaderEmail && submission.leaderEmail.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  if (!collection) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading collection...</p>
        </div>
      </div>
    )
  }

  const isExpired = new Date(collection.expiresAt) < new Date()
  const timeRemaining = formatDistanceToNow(new Date(collection.expiresAt), { addSuffix: true })

  // Password protection screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="card max-w-md w-full"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Protected Collection</h1>
            <p className="text-gray-600">Enter the password to access this collection</p>
          </div>

          <div className="mb-6">
            <h2 className="font-semibold text-gray-800 mb-2">
              {collection.sectionBatch} - {collection.courseCode}
            </h2>
            <p className="text-sm text-gray-600">{collection.semester}</p>
            <p className="text-sm text-gray-600">{collection.department}</p>
          </div>

          <form onSubmit={handlePasswordSubmit}>
            <div className="mb-4">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter collection password"
                className={`input-field ${passwordError ? "border-red-500" : ""}`}
                autoFocus
              />
              {passwordError && <p className="text-red-500 text-sm mt-1">{passwordError}</p>}
            </div>

            <button type="submit" className="w-full btn-primary">
              Access Collection
            </button>
          </form>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Collection Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="card mb-8"
        >
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {collection.sectionBatch} - {collection.courseCode}
              </h1>
              <p className="text-gray-600 mb-4">{collection.semester}</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <BookOpen size={16} />
                  <span>{collection.department}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Users size={16} />
                  <span>{submissions.length} submissions</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock size={16} />
                  <span className={isExpired ? "text-red-600" : "text-green-600"}>
                    {isExpired ? "Expired" : `Expires ${timeRemaining}`}
                  </span>
                </div>
              </div>

              {collection.description && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <p className="text-gray-700">{collection.description}</p>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              {!isExpired && (
                <button
                  onClick={() => setShowSubmissionForm(!showSubmissionForm)}
                  className="btn-primary inline-flex items-center justify-center gap-2"
                >
                  <Plus size={20} />
                  Submit Slides
                </button>
              )}
            </div>
          </div>
        </motion.div>

        {/* Submission Form */}
        {showSubmissionForm && !isExpired && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="card mb-8"
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Submit Your Slides</h2>

            <form onSubmit={handleSubmissionSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Team Name *</label>
                  <input
                    type="text"
                    name="teamName"
                    value={submissionForm.teamName}
                    onChange={handleSubmissionChange}
                    placeholder="Enter your team name"
                    className={`input-field ${submissionErrors.teamName ? "border-red-500" : ""}`}
                  />
                  {submissionErrors.teamName && (
                    <p className="text-red-500 text-sm mt-1">{submissionErrors.teamName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Team Leader Email (Optional)</label>
                  <input
                    type="email"
                    name="leaderEmail"
                    value={submissionForm.leaderEmail}
                    onChange={handleSubmissionChange}
                    placeholder="leader@example.com"
                    className={`input-field ${submissionErrors.leaderEmail ? "border-red-500" : ""}`}
                  />
                  {submissionErrors.leaderEmail && (
                    <p className="text-red-500 text-sm mt-1">{submissionErrors.leaderEmail}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Slide Link *</label>
                <input
                  type="url"
                  name="slideLink"
                  value={submissionForm.slideLink}
                  onChange={handleSubmissionChange}
                  placeholder="https://drive.google.com/... or https://onedrive.live.com/..."
                  className={`input-field ${submissionErrors.slideLink ? "border-red-500" : ""}`}
                />
                {submissionErrors.slideLink && (
                  <p className="text-red-500 text-sm mt-1">{submissionErrors.slideLink}</p>
                )}
                <p className="text-gray-500 text-sm mt-1">
                  Please provide a Google Drive or OneDrive link to your slides
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes (Optional)</label>
                <textarea
                  name="notes"
                  value={submissionForm.notes}
                  onChange={handleSubmissionChange}
                  placeholder="Any additional information..."
                  rows={3}
                  className="input-field resize-none"
                />
              </div>

              <div className="flex gap-3">
                <button type="submit" className="btn-primary">
                  Submit Slides
                </button>
                <button type="button" onClick={() => setShowSubmissionForm(false)} className="btn-secondary">
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* Submissions List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="card"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Submissions ({submissions.length})</h2>

            {submissions.length > 0 && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                <input
                  type="text"
                  placeholder="Search submissions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input-field pl-10 w-full sm:w-64"
                />
              </div>
            )}
          </div>

          {filteredSubmissions.length > 0 ? (
            <div className="space-y-4">
              {filteredSubmissions.map((submission, index) => (
                <motion.div
                  key={submission.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-800">
                          #{index + 1} {submission.teamName}
                        </h3>
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                          {formatDistanceToNow(new Date(submission.submittedAt), { addSuffix: true })}
                        </span>
                      </div>

                      {submission.leaderEmail && (
                        <p className="text-sm text-gray-600 mb-2">Leader: {submission.leaderEmail}</p>
                      )}

                      {submission.notes && <p className="text-sm text-gray-600 mb-2">Notes: {submission.notes}</p>}
                    </div>

                    <a
                      href={submission.slideLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-secondary inline-flex items-center gap-2 text-sm"
                    >
                      <ExternalLink size={16} />
                      View Slides
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-500 mb-2">
                {submissions.length === 0 ? "No Submissions Yet" : "No Submissions Found"}
              </h3>
              <p className="text-gray-400">
                {submissions.length === 0
                  ? "Submissions will appear here once students start submitting their slides"
                  : "Try adjusting your search criteria"}
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
