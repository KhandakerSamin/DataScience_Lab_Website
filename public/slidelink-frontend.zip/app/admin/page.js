"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Shield, Trash2, Eye, Search, FileText, Clock, Users, AlertCircle } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import Link from "next/link"

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [collections, setCollections] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [stats, setStats] = useState({ total: 0, active: 0, expired: 0, submissions: 0 })

  const ADMIN_PASSWORD = "admin123" // Simple admin password

  useEffect(() => {
    if (isAuthenticated) {
      loadCollections()
    }
  }, [isAuthenticated])

  const loadCollections = () => {
    const stored = JSON.parse(localStorage.getItem("slidelink_collections") || "[]")
    setCollections(stored)

    // Calculate stats
    const now = new Date()
    const active = stored.filter((c) => new Date(c.expiresAt) > now).length
    const expired = stored.filter((c) => new Date(c.expiresAt) <= now).length
    const totalSubmissions = stored.reduce((sum, c) => sum + (c.submissions?.length || 0), 0)

    setStats({
      total: stored.length,
      active,
      expired,
      submissions: totalSubmissions,
    })
  }

  const handlePasswordSubmit = (e) => {
    e.preventDefault()
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      setPasswordError("")
    } else {
      setPasswordError("Incorrect admin password")
    }
  }

  const handleDeleteCollection = (collectionId) => {
    if (confirm("Are you sure you want to delete this collection? This action cannot be undone.")) {
      const updated = collections.filter((c) => c.id !== collectionId)
      setCollections(updated)
      localStorage.setItem("slidelink_collections", JSON.stringify(updated))
      loadCollections() // Refresh stats
    }
  }

  const filteredCollections = collections.filter(
    (collection) =>
      collection.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      collection.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      collection.sectionBatch.toLowerCase().includes(searchTerm.toLowerCase()) ||
      collection.department.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Admin login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="card max-w-md w-full"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Enter admin password to continue</p>
          </div>

          <form onSubmit={handlePasswordSubmit}>
            <div className="mb-4">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                className={`input-field ${passwordError ? "border-red-500" : ""}`}
                autoFocus
              />
              {passwordError && <p className="text-red-500 text-sm mt-1">{passwordError}</p>}
            </div>

            <button type="submit" className="w-full btn-primary">
              Access Dashboard
            </button>
          </form>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage collections and view analytics</p>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <div className="card text-center">
            <FileText className="w-8 h-8 text-blue-500 mx-auto mb-3" />
            <h3 className="text-2xl font-bold text-gray-800">{stats.total}</h3>
            <p className="text-gray-600">Total Collections</p>
          </div>
          <div className="card text-center">
            <Clock className="w-8 h-8 text-green-500 mx-auto mb-3" />
            <h3 className="text-2xl font-bold text-gray-800">{stats.active}</h3>
            <p className="text-gray-600">Active Collections</p>
          </div>
          <div className="card text-center">
            <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
            <h3 className="text-2xl font-bold text-gray-800">{stats.expired}</h3>
            <p className="text-gray-600">Expired Collections</p>
          </div>
          <div className="card text-center">
            <Users className="w-8 h-8 text-purple-500 mx-auto mb-3" />
            <h3 className="text-2xl font-bold text-gray-800">{stats.submissions}</h3>
            <p className="text-gray-600">Total Submissions</p>
          </div>
        </motion.div>

        {/* Search and Collections */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="card"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <h2 className="text-xl font-semibold text-gray-800">All Collections</h2>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <input
                type="text"
                placeholder="Search collections..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-10 w-full sm:w-64"
              />
            </div>
          </div>

          {filteredCollections.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Collection</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Department</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Submissions</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Created</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCollections.map((collection) => {
                    const isExpired = new Date(collection.expiresAt) < new Date()
                    const deptCode = collection.id.split("-").pop()

                    return (
                      <tr key={collection.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div>
                            <div className="font-medium text-gray-800">
                              {collection.sectionBatch} - {collection.courseCode}
                            </div>
                            <div className="text-sm text-gray-600">{collection.semester}</div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600">
                          {collection.department.split(" ").slice(-1)[0].replace(/[()]/g, "")}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              isExpired ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                            }`}
                          >
                            {isExpired ? "Expired" : "Active"}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600">{collection.submissions?.length || 0}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">
                          {formatDistanceToNow(new Date(collection.createdAt), { addSuffix: true })}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Link
                              href={`/collection/${deptCode.toLowerCase()}/${collection.id}`}
                              className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                              title="View Collection"
                            >
                              <Eye size={16} />
                            </Link>
                            <button
                              onClick={() => handleDeleteCollection(collection.id)}
                              className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                              title="Delete Collection"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-500 mb-2">
                {collections.length === 0 ? "No Collections Yet" : "No Collections Found"}
              </h3>
              <p className="text-gray-400">
                {collections.length === 0
                  ? "Collections will appear here once they are created"
                  : "Try adjusting your search criteria"}
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
