# SlideLink Backend

SlideLink Backend is the API server for the SlideLink academic slide collection platform. Built with Express.js, Node.js, and MongoDB.

## Features

- **Collection Management**: Create, read, update, delete slide collections
- **Submission System**: Handle team slide submissions with validation
- **Contact System**: Process contact form submissions
- **Admin Dashboard**: Administrative functions and statistics
- **Security**: Rate limiting, CORS, input validation, password hashing
- **Database**: MongoDB with proper indexing for performance

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB (native driver, no Mongoose)
- **Security**: Helmet, CORS, Rate Limiting, bcryptjs
- **Validation**: Custom validation utilities
- **Logging**: Morgan

## Installation & Setup

### Prerequisites
- Node.js 16+ installed
- MongoDB Atlas account (or local MongoDB)
- Git

### 1. Download/Extract the Project
\`\`\`bash
# Extract to SlideLink-Backend folder
cd SlideLink-Backend
\`\`\`

### 2. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 3. Environment Configuration
The `.env` file is already included with the MongoDB connection string:
\`\`\`env
MONGODB_URI=mongodb+srv://SlideLinkAdmin:HozNJY2fYVuX3w0J@cluster0.vheow1k.mongodb.net/slidelinkDB?retryWrites=true&w=majority&appName=Cluster0
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
ADMIN_PASSWORD=admin123
\`\`\`

### 4. Start the Server

**Development Mode:**
\`\`\`bash
npm run dev
\`\`\`

**Production Mode:**
\`\`\`bash
npm start
\`\`\`

The server will start on `http://localhost:5000`

## API Endpoints

### Collections
- `GET /api/collections` - Get all collections (public info)
- `POST /api/collections` - Create new collection
- `GET /api/collections/:id` - Get collection by ID (requires password)
- `DELETE /api/collections/:id` - Delete collection (admin)

### Submissions
- `POST /api/submissions` - Create new submission
- `GET /api/submissions/:collectionId` - Get submissions for collection
- `DELETE /api/submissions/:id` - Delete submission (admin)

### Contact
- `POST /api/contact` - Submit contact form
- `GET /api/contact` - Get contact messages (admin)
- `PUT /api/contact/:id/read` - Mark message as read

### Admin
- `GET /api/admin/stats` - Get dashboard statistics
- `POST /api/admin/cleanup` - Clean up old data

### Health Check
- `GET /api/health` - Server health status

## Project Structure

\`\`\`
SlideLink-Backend/
├── config/
│   └── database.js      # MongoDB connection
├── routes/
│   ├── collections.js   # Collection routes
│   ├── submissions.js   # Submission routes
│   ├── contact.js       # Contact routes
│   └── admin.js         # Admin routes
├── utils/
│   ├── validation.js    # Validation utilities
│   └── constants.js     # App constants
├── .env                 # Environment variables
├── server.js            # Main server file
└── package.json         # Dependencies
\`\`\`

## Security Features

- **Rate Limiting**: 100 requests per 15 minutes per IP
- **CORS**: Configured for frontend domain
- **Helmet**: Security headers
- **Input Validation**: Comprehensive validation for all inputs
- **Password Hashing**: bcryptjs for secure password storage
- **MongoDB Injection Protection**: Parameterized queries

## Support

For technical support:
- Email: support@slidelink.edu
- Phone: +880 1234-567890

## License

MIT License - see LICENSE file for details
