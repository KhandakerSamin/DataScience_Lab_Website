const { MongoClient } = require("mongodb")

let db = null
let client = null

/**
 * Connect to MongoDB database
 */
const connectDB = async () => {
  try {
    if (db) {
      console.log("📦 Using existing MongoDB connection")
      return db
    }

    console.log("🔌 Connecting to MongoDB...")

    client = new MongoClient(process.env.MONGODB_URI, {
      useUnifiedTopology: true,
    })

    await client.connect()
    db = client.db("slidelinkDB")

    console.log("✅ MongoDB connected successfully")

    // Create indexes for better performance
    await createIndexes()

    return db
  } catch (error) {
    console.error("❌ MongoDB connection error:", error.message)
    process.exit(1)
  }
}

/**
 * Create database indexes for better performance
 */
const createIndexes = async () => {
  try {
    // Collections indexes
    await db.collection("collections").createIndex({ id: 1 }, { unique: true })
    await db.collection("collections").createIndex({ createdAt: -1 })
    await db.collection("collections").createIndex({ expiresAt: 1 })
    await db.collection("collections").createIndex({
      courseCode: 1,
      sectionBatch: 1,
      semester: 1,
    })

    // Submissions indexes
    await db.collection("submissions").createIndex({ collectionId: 1 })
    await db.collection("submissions").createIndex({ submittedAt: -1 })
    await db.collection("submissions").createIndex(
      {
        collectionId: 1,
        teamName: 1,
      },
      { unique: true },
    )

    // Contact messages indexes
    await db.collection("contacts").createIndex({ timestamp: -1 })
    await db.collection("contacts").createIndex({ email: 1 })

    console.log("📊 Database indexes created successfully")
  } catch (error) {
    console.error("⚠️ Error creating indexes:", error.message)
  }
}

/**
 * Get database instance
 */
const getDB = () => {
  if (!db) {
    throw new Error("Database not connected. Call connectDB first.")
  }
  return db
}

/**
 * Close database connection
 */
const closeDB = async () => {
  if (client) {
    await client.close()
    db = null
    client = null
    console.log("🔌 MongoDB connection closed")
  }
}

module.exports = {
  connectDB,
  getDB,
  closeDB,
}
