"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Clock, Users, BookOpen, Calendar } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

export default function CollectionCard({ collection }) {
  const isExpired = new Date(collection.expiresAt) < new Date()
  const timeRemaining = formatDistanceToNow(new Date(collection.expiresAt), { addSuffix: true })

  // Extract department code from collection ID
  const deptCode = collection.id.split("-").pop()

  return (
    <motion.div whileHover={{ y: -5, shadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1)" }} className="card h-full">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-800 mb-1">
            {collection.sectionBatch} - {collection.courseCode}
          </h3>
          <p className="text-sm text-gray-600">{collection.semester}</p>
        </div>
        <div
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            isExpired ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
          }`}
        >
          {isExpired ? "Expired" : "Active"}
        </div>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <BookOpen size={14} />
          <span className="truncate">{collection.department}</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Users size={14} />
          <span>{collection.submissions?.length || 0} submissions</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock size={14} />
          <span>{isExpired ? "Expired" : `Expires ${timeRemaining}`}</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar size={14} />
          <span>{formatDistanceToNow(new Date(collection.createdAt), { addSuffix: true })}</span>
        </div>
      </div>

      {collection.description && <p className="text-sm text-gray-600 mb-4 line-clamp-2">{collection.description}</p>}

      <Link
        href={`/collection/${deptCode.toLowerCase()}/${collection.id}`}
        className="block w-full text-center bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-2 rounded-lg font-medium hover:from-blue-600 hover:to-indigo-700 transition-all duration-200"
      >
        View Collection
      </Link>
    </motion.div>
  )
}
