"use client"

import { useEffect, useRef, useState } from "react"
import QRCode from "qrcode"
import { Download, Share2 } from "lucide-react"

export default function QRCodeGenerator({ url }) {
  const canvasRef = useRef(null)
  const [qrDataUrl, setQrDataUrl] = useState("")

  useEffect(() => {
    if (url && canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        url,
        {
          width: 256,
          margin: 2,
          color: {
            dark: "#1f2937",
            light: "#ffffff",
          },
        },
        (error) => {
          if (error) console.error("QR Code generation error:", error)
        },
      )

      // Also generate data URL for download
      QRCode.toDataURL(
        url,
        {
          width: 256,
          margin: 2,
          color: {
            dark: "#1f2937",
            light: "#ffffff",
          },
        },
        (error, dataUrl) => {
          if (!error) setQrDataUrl(dataUrl)
        },
      )
    }
  }, [url])

  const downloadQR = () => {
    if (qrDataUrl) {
      const link = document.createElement("a")
      link.download = "slidelink-qr-code.png"
      link.href = qrDataUrl
      link.click()
    }
  }

  const shareQR = async () => {
    if (navigator.share && qrDataUrl) {
      try {
        // Convert data URL to blob
        const response = await fetch(qrDataUrl)
        const blob = await response.blob()
        const file = new File([blob], "slidelink-qr-code.png", { type: "image/png" })

        await navigator.share({
          title: "SlideLink Collection QR Code",
          text: "Scan this QR code to access the slide collection",
          files: [file],
        })
      } catch (error) {
        console.error("Error sharing QR code:", error)
        // Fallback to copying URL
        navigator.clipboard.writeText(url)
      }
    } else {
      // Fallback to copying URL
      navigator.clipboard.writeText(url)
    }
  }

  return (
    <div className="flex flex-col items-center">
      <div className="p-4 bg-white rounded-lg shadow-sm border mb-4">
        <canvas ref={canvasRef} className="block" />
      </div>

      <div className="flex gap-2">
        <button
          onClick={downloadQR}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors text-sm"
        >
          <Download size={16} />
          Download
        </button>

        <button
          onClick={shareQR}
          className="flex items-center gap-2 px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg transition-colors text-sm"
        >
          <Share2 size={16} />
          Share
        </button>
      </div>
    </div>
  )
}
