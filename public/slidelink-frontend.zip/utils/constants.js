// Faculty and Department structure for SlideLink
const FACULTIES = [
  {
    name: "Faculty of Science and Information Technology (FSIT)",
    departments: [
      { name: "Department of Computer Science & Engineering", code: "CSE" },
      { name: "Department of Computing & Information System", code: "CIS" },
      { name: "Department of Software Engineering", code: "SWE" },
      { name: "Department of Environmental Science and Disaster Management", code: "ESDM" },
      { name: "Department of Multimedia & Creative Technology", code: "MCT" },
      { name: "Department of Information Technology and Management", code: "ITM" },
      { name: "Department of Physical Education & Sports Science", code: "PESS" },
    ],
  },
  {
    name: "Faculty of Business and Entrepreneurship (FBE)",
    departments: [
      { name: "Department of Business Administration", code: "BBA" },
      { name: "Department of Management", code: "MGT" },
      { name: "Department of Real Estate", code: "RE" },
      { name: "Department of Tourism & Hospitality Management", code: "THM" },
      { name: "Department of Innovation & Entrepreneurship", code: "IE" },
      { name: "Department of Finance and Banking", code: "FB" },
      { name: "Department of Accounting", code: "ACC" },
      { name: "Department of Marketing", code: "MKT" },
    ],
  },
  {
    name: "Faculty of Engineering (FE)",
    departments: [
      { name: "Department of Information and Communication Engineering", code: "ICE" },
      { name: "Department of Textile Engineering", code: "TE" },
      { name: "Department of Electrical & Electronic Engineering", code: "EEE" },
      { name: "Department of Architecture", code: "ARCH" },
      { name: "Department of Civil Engineering", code: "CE" },
    ],
  },
  {
    name: "Faculty of Health and Life Sciences (FHLS)",
    departments: [
      { name: "Department of Pharmacy", code: "PHARM" },
      { name: "Department of Public Health", code: "PH" },
      { name: "Department of Nutrition & Food Engineering", code: "NFE" },
      { name: "Department of Agricultural Science", code: "AGS" },
      { name: "Department of Genetic Engineering and Biotechnology", code: "GEB" },
    ],
  },
  {
    name: "Faculty of Humanities and Social Sciences (FHSS)",
    departments: [
      { name: "Department of English", code: "ENG" },
      { name: "Department of Law", code: "LAW" },
      { name: "Department of Journalism & Mass Communication", code: "JMC" },
      { name: "Department of Development Studies", code: "DS" },
      { name: "Department of Information Science and Library Management", code: "ISLM" },
    ],
  },
]

module.exports = {
  FACULTIES,
}
