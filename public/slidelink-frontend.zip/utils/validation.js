const { FACULTIES } = require("./constants")

/**
 * Validate collection data
 */
const validateCollection = (data) => {
  const errors = {}

  // Section & Batch validation
  if (!data.sectionBatch) {
    errors.sectionBatch = "Section & Batch is required"
  } else if (!/^\d{2}-[A-Z]$/.test(data.sectionBatch)) {
    errors.sectionBatch = 'Format should be like "42-E"'
  }

  // Course Code validation
  if (!data.courseCode) {
    errors.courseCode = "Course Code is required"
  } else if (!/^[A-Z]{2,4}\d{3}$/.test(data.courseCode)) {
    errors.courseCode = 'Format should be like "SE112" or "CSE101"'
  }

  // Semester validation
  if (!data.semester) {
    errors.semester = "Semester is required"
  }

  // Faculty validation
  if (!data.faculty) {
    errors.faculty = "Faculty is required"
  } else if (!FACULTIES.find((f) => f.name === data.faculty)) {
    errors.faculty = "Invalid faculty selected"
  }

  // Department validation
  if (!data.department) {
    errors.department = "Department is required"
  } else {
    const faculty = FACULTIES.find((f) => f.name === data.faculty)
    if (faculty && !faculty.departments.find((d) => d.name === data.department)) {
      errors.department = "Invalid department for selected faculty"
    }
  }

  // Password validation
  if (!data.password) {
    errors.password = "Password is required"
  } else if (data.password.length < 4) {
    errors.password = "Password must be at least 4 characters"
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}

/**
 * Validate submission data
 */
const validateSubmission = (data) => {
  const errors = {}

  // Collection ID validation
  if (!data.collectionId) {
    errors.collectionId = "Collection ID is required"
  }

  // Team Name validation
  if (!data.teamName) {
    errors.teamName = "Team name is required"
  } else if (data.teamName.trim().length < 2) {
    errors.teamName = "Team name must be at least 2 characters"
  }

  // Slide Link validation
  if (!data.slideLink) {
    errors.slideLink = "Slide link is required"
  } else if (!isValidSlideLink(data.slideLink)) {
    errors.slideLink = "Please provide a valid Google Drive or OneDrive link"
  }

  // Email validation (optional)
  if (data.leaderEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.leaderEmail)) {
    errors.leaderEmail = "Please provide a valid email address"
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}

/**
 * Validate contact form data
 */
const validateContact = (data) => {
  const errors = {}

  // Name validation
  if (!data.name) {
    errors.name = "Name is required"
  } else if (data.name.trim().length < 2) {
    errors.name = "Name must be at least 2 characters"
  }

  // Email validation
  if (!data.email) {
    errors.email = "Email is required"
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = "Please provide a valid email address"
  }

  // Subject validation
  if (!data.subject) {
    errors.subject = "Subject is required"
  } else if (data.subject.trim().length < 5) {
    errors.subject = "Subject must be at least 5 characters"
  }

  // Message validation
  if (!data.message) {
    errors.message = "Message is required"
  } else if (data.message.trim().length < 10) {
    errors.message = "Message must be at least 10 characters"
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}

/**
 * Validate slide link URLs
 */
const isValidSlideLink = (url) => {
  const validDomains = ["drive.google.com", "docs.google.com", "onedrive.live.com", "1drv.ms"]

  try {
    const urlObj = new URL(url)
    return validDomains.some((domain) => urlObj.hostname.includes(domain))
  } catch {
    return false
  }
}

/**
 * Generate collection ID
 */
const generateCollectionId = (sectionBatch, courseCode, department) => {
  const year = new Date().getFullYear()
  const faculty = FACULTIES.find((f) => f.departments.some((d) => d.name === department))
  const dept = faculty.departments.find((d) => d.name === department)

  return `${sectionBatch}-${courseCode}-${year}-${dept.code}`
}

module.exports = {
  validateCollection,
  validateSubmission,
  validateContact,
  isValidSlideLink,
  generateCollectionId,
}
