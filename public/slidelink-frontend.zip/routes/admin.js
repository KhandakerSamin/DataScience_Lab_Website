const express = require("express")
const { getDB } = require("../config/database")

const router = express.Router()

/**
 * GET /api/admin/stats
 * Get admin dashboard statistics
 */
router.get("/stats", async (req, res) => {
  try {
    const db = getDB()
    const now = new Date()

    // Get collection stats
    const totalCollections = await db.collection("collections").countDocuments()
    const activeCollections = await db.collection("collections").countDocuments({ expiresAt: { $gt: now } })
    const expiredCollections = await db.collection("collections").countDocuments({ expiresAt: { $lte: now } })

    // Get submission stats
    const totalSubmissions = await db.collection("submissions").countDocuments()

    // Get contact stats
    const totalContacts = await db.collection("contacts").countDocuments()
    const unreadContacts = await db.collection("contacts").countDocuments({ isRead: false })

    // Get recent activity (last 7 days)
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    const recentCollections = await db.collection("collections").countDocuments({ createdAt: { $gte: weekAgo } })
    const recentSubmissions = await db.collection("submissions").countDocuments({ submittedAt: { $gte: weekAgo } })

    // Get top departments by collection count
    const departmentStats = await db
      .collection("collections")
      .aggregate([
        {
          $group: {
            _id: "$department",
            count: { $sum: 1 },
            activeCount: {
              $sum: {
                $cond: [{ $gt: ["$expiresAt", now] }, 1, 0],
              },
            },
          },
        },
        { $sort: { count: -1 } },
        { $limit: 5 },
      ])
      .toArray()

    res.json({
      success: true,
      data: {
        collections: {
          total: totalCollections,
          active: activeCollections,
          expired: expiredCollections,
        },
        submissions: {
          total: totalSubmissions,
        },
        contacts: {
          total: totalContacts,
          unread: unreadContacts,
        },
        recentActivity: {
          collections: recentCollections,
          submissions: recentSubmissions,
        },
        topDepartments: departmentStats,
      },
    })
  } catch (error) {
    console.error("Error fetching admin stats:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch admin statistics",
    })
  }
})

/**
 * POST /api/admin/cleanup
 * Clean up expired collections and old data
 */
router.post("/cleanup", async (req, res) => {
  try {
    const db = getDB()
    const now = new Date()
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)

    // Delete expired collections older than 30 days
    const expiredCollections = await db
      .collection("collections")
      .find({
        expiresAt: { $lte: thirtyDaysAgo },
      })
      .toArray()

    const expiredCollectionIds = expiredCollections.map((c) => c.id)

    // Delete expired collections
    const deletedCollections = await db.collection("collections").deleteMany({
      expiresAt: { $lte: thirtyDaysAgo },
    })

    // Delete submissions for expired collections
    const deletedSubmissions = await db.collection("submissions").deleteMany({
      collectionId: { $in: expiredCollectionIds },
    })

    // Delete old contact messages (older than 90 days)
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
    const deletedContacts = await db.collection("contacts").deleteMany({
      timestamp: { $lte: ninetyDaysAgo },
    })

    res.json({
      success: true,
      message: "Cleanup completed successfully",
      data: {
        deletedCollections: deletedCollections.deletedCount,
        deletedSubmissions: deletedSubmissions.deletedCount,
        deletedContacts: deletedContacts.deletedCount,
      },
    })
  } catch (error) {
    console.error("Error during cleanup:", error)
    res.status(500).json({
      success: false,
      message: "Failed to perform cleanup",
    })
  }
})

module.exports = router
