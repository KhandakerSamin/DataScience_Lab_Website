const express = require("express")
const { getDB } = require("../config/database")
const { validateContact } = require("../utils/validation")

const router = express.Router()

/**
 * POST /api/contact
 * Submit contact form
 */
router.post("/", async (req, res) => {
  try {
    const db = getDB()

    // Validate input
    const validation = validateContact(req.body)
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validation.errors,
      })
    }

    const { name, email, subject, message } = req.body

    // Create contact message object
    const contactMessage = {
      name,
      email,
      subject,
      message,
      timestamp: new Date(),
      ipAddress: req.ip || req.connection.remoteAddress,
      userAgent: req.get("User-Agent"),
      isRead: false,
    }

    // Insert contact message
    const result = await db.collection("contacts").insertOne(contactMessage)

    res.status(201).json({
      success: true,
      message: "Contact message sent successfully",
      data: {
        id: result.insertedId,
        timestamp: contactMessage.timestamp,
      },
    })
  } catch (error) {
    console.error("Error submitting contact form:", error)
    res.status(500).json({
      success: false,
      message: "Failed to submit contact form",
    })
  }
})

/**
 * GET /api/contact
 * Get all contact messages (admin only)
 */
router.get("/", async (req, res) => {
  try {
    const db = getDB()
    const { page = 1, limit = 20, unread } = req.query

    // Build query
    const query = {}
    if (unread === "true") {
      query.isRead = false
    }

    // Get contact messages with pagination
    const messages = await db
      .collection("contacts")
      .find(query)
      .sort({ timestamp: -1 })
      .skip((page - 1) * limit)
      .limit(Number.parseInt(limit))
      .toArray()

    // Get total count
    const total = await db.collection("contacts").countDocuments(query)
    const unreadCount = await db.collection("contacts").countDocuments({ isRead: false })

    res.json({
      success: true,
      data: {
        messages,
        pagination: {
          page: Number.parseInt(page),
          limit: Number.parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
        unreadCount,
      },
    })
  } catch (error) {
    console.error("Error fetching contact messages:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch contact messages",
    })
  }
})

/**
 * PUT /api/contact/:id/read
 * Mark contact message as read
 */
router.put("/:id/read", async (req, res) => {
  try {
    const db = getDB()
    const { id } = req.params

    // Update message as read
    const result = await db
      .collection("contacts")
      .updateOne({ _id: new require("mongodb").ObjectId(id) }, { $set: { isRead: true, readAt: new Date() } })

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Contact message not found",
      })
    }

    res.json({
      success: true,
      message: "Message marked as read",
    })
  } catch (error) {
    console.error("Error marking message as read:", error)
    res.status(500).json({
      success: false,
      message: "Failed to mark message as read",
    })
  }
})

module.exports = router
