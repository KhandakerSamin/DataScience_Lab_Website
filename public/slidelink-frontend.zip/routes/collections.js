const express = require("express")
const bcrypt = require("bcryptjs")
const { getDB } = require("../config/database")
const { validateCollection, generateCollectionId } = require("../utils/validation")

const router = express.Router()

/**
 * GET /api/collections
 * Get all collections (public info only)
 */
router.get("/", async (req, res) => {
  try {
    const db = getDB()
    const { page = 1, limit = 10, search, department, status } = req.query

    // Build query
    const query = {}

    if (search) {
      query.$or = [
        { courseCode: { $regex: search, $options: "i" } },
        { sectionBatch: { $regex: search, $options: "i" } },
        { id: { $regex: search, $options: "i" } },
      ]
    }

    if (department) {
      query.department = { $regex: department, $options: "i" }
    }

    if (status === "active") {
      query.expiresAt = { $gt: new Date() }
    } else if (status === "expired") {
      query.expiresAt = { $lte: new Date() }
    }

    // Get collections with pagination
    const collections = await db
      .collection("collections")
      .find(query, {
        projection: {
          password: 0, // Exclude password from response
        },
      })
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number.parseInt(limit))
      .toArray()

    // Get total count
    const total = await db.collection("collections").countDocuments(query)

    // Add submission counts
    for (const collection of collections) {
      const submissionCount = await db.collection("submissions").countDocuments({ collectionId: collection.id })
      collection.submissionCount = submissionCount
    }

    res.json({
      success: true,
      data: {
        collections,
        pagination: {
          page: Number.parseInt(page),
          limit: Number.parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    console.error("Error fetching collections:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch collections",
    })
  }
})

/**
 * POST /api/collections
 * Create a new collection
 */
router.post("/", async (req, res) => {
  try {
    const db = getDB()

    // Validate input
    const validation = validateCollection(req.body)
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validation.errors,
      })
    }

    const { sectionBatch, courseCode, semester, faculty, department, password, description } = req.body

    // Generate collection ID
    const collectionId = generateCollectionId(sectionBatch, courseCode, department)

    // Check if collection already exists
    const existingCollection = await db.collection("collections").findOne({ id: collectionId })

    if (existingCollection) {
      return res.status(409).json({
        success: false,
        message: "Collection with this ID already exists",
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create collection object
    const collection = {
      id: collectionId,
      sectionBatch,
      courseCode,
      semester,
      faculty,
      department,
      password: hashedPassword,
      description: description || "",
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      isActive: true,
    }

    // Insert collection
    await db.collection("collections").insertOne(collection)

    // Return collection without password
    const { password: _, ...collectionResponse } = collection

    res.status(201).json({
      success: true,
      message: "Collection created successfully",
      data: collectionResponse,
    })
  } catch (error) {
    console.error("Error creating collection:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create collection",
    })
  }
})

/**
 * GET /api/collections/:id
 * Get collection by ID (requires password)
 */
router.get("/:id", async (req, res) => {
  try {
    const db = getDB()
    const { id } = req.params
    const { password } = req.query

    // Find collection
    const collection = await db.collection("collections").findOne({ id })

    if (!collection) {
      return res.status(404).json({
        success: false,
        message: "Collection not found",
      })
    }

    // Check password if provided
    if (password) {
      const isValidPassword = await bcrypt.compare(password, collection.password)

      if (!isValidPassword) {
        return res.status(401).json({
          success: false,
          message: "Invalid password",
        })
      }

      // Get submissions for this collection
      const submissions = await db
        .collection("submissions")
        .find({ collectionId: id })
        .sort({ submittedAt: -1 })
        .toArray()

      // Return full collection data with submissions
      const { password: _, ...collectionData } = collection

      res.json({
        success: true,
        data: {
          ...collectionData,
          submissions,
        },
      })
    } else {
      // Return basic collection info without password
      const { password: _, ...collectionData } = collection

      res.json({
        success: true,
        data: collectionData,
      })
    }
  } catch (error) {
    console.error("Error fetching collection:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch collection",
    })
  }
})

/**
 * DELETE /api/collections/:id
 * Delete collection (admin only)
 */
router.delete("/:id", async (req, res) => {
  try {
    const db = getDB()
    const { id } = req.params

    // Delete collection
    const result = await db.collection("collections").deleteOne({ id })

    if (result.deletedCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Collection not found",
      })
    }

    // Delete associated submissions
    await db.collection("submissions").deleteMany({ collectionId: id })

    res.json({
      success: true,
      message: "Collection deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting collection:", error)
    res.status(500).json({
      success: false,
      message: "Failed to delete collection",
    })
  }
})

module.exports = router
