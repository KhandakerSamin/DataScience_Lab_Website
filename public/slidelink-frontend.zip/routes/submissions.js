const express = require("express")
const { getDB } = require("../config/database")
const { validateSubmission, isValidSlideLink } = require("../utils/validation")

const router = express.Router()

/**
 * POST /api/submissions
 * Create a new submission
 */
router.post("/", async (req, res) => {
  try {
    const db = getDB()

    // Validate input
    const validation = validateSubmission(req.body)
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validation.errors,
      })
    }

    const { collectionId, teamName, slideLink, leaderEmail, notes } = req.body

    // Check if collection exists and is active
    const collection = await db.collection("collections").findOne({ id: collectionId })

    if (!collection) {
      return res.status(404).json({
        success: false,
        message: "Collection not found",
      })
    }

    // Check if collection is expired
    if (new Date() > new Date(collection.expiresAt)) {
      return res.status(400).json({
        success: false,
        message: "Collection has expired",
      })
    }

    // Check if team name already exists in this collection
    const existingSubmission = await db
      .collection("submissions")
      .findOne({ collectionId, teamName: { $regex: `^${teamName}$`, $options: "i" } })

    if (existingSubmission) {
      return res.status(409).json({
        success: false,
        message: "Team name already exists in this collection",
      })
    }

    // Validate slide link
    if (!isValidSlideLink(slideLink)) {
      return res.status(400).json({
        success: false,
        message: "Please provide a valid Google Drive or OneDrive link",
      })
    }

    // Create submission object
    const submission = {
      collectionId,
      teamName,
      slideLink,
      leaderEmail: leaderEmail || "",
      notes: notes || "",
      submittedAt: new Date(),
      ipAddress: req.ip || req.connection.remoteAddress,
    }

    // Insert submission
    const result = await db.collection("submissions").insertOne(submission)

    res.status(201).json({
      success: true,
      message: "Submission created successfully",
      data: {
        id: result.insertedId,
        ...submission,
      },
    })
  } catch (error) {
    console.error("Error creating submission:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create submission",
    })
  }
})

/**
 * GET /api/submissions/:collectionId
 * Get submissions for a collection
 */
router.get("/:collectionId", async (req, res) => {
  try {
    const db = getDB()
    const { collectionId } = req.params
    const { search, page = 1, limit = 50 } = req.query

    // Build query
    const query = { collectionId }

    if (search) {
      query.$or = [{ teamName: { $regex: search, $options: "i" } }, { leaderEmail: { $regex: search, $options: "i" } }]
    }

    // Get submissions with pagination
    const submissions = await db
      .collection("submissions")
      .find(query)
      .sort({ submittedAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number.parseInt(limit))
      .toArray()

    // Get total count
    const total = await db.collection("submissions").countDocuments(query)

    res.json({
      success: true,
      data: {
        submissions,
        pagination: {
          page: Number.parseInt(page),
          limit: Number.parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    console.error("Error fetching submissions:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch submissions",
    })
  }
})

/**
 * DELETE /api/submissions/:id
 * Delete submission (admin only)
 */
router.delete("/:id", async (req, res) => {
  try {
    const db = getDB()
    const { id } = req.params

    // Delete submission
    const result = await db.collection("submissions").deleteOne({
      _id: new require("mongodb").ObjectId(id),
    })

    if (result.deletedCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Submission not found",
      })
    }

    res.json({
      success: true,
      message: "Submission deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting submission:", error)
    res.status(500).json({
      success: false,
      message: "Failed to delete submission",
    })
  }
})

module.exports = router
